
import streamlit as st
from transformers import BertTokenizer, BertForSequenceClassification
import torch

MODEL_PATH = "./bert_spam_model/best_model"

@st.cache_resource
def load_model():
tokenizer = BertTokenizer.from_pretrained(MODEL_PATH)
model = BertForSequenceClassification.from_pretrained(MODEL_PATH)
model.eval()
return tokenizer, model

tokenizer, model = load_model()

def predict_spam(text):
inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=128)
with torch.no_grad():
outputs = model(**inputs)
probs = torch.softmax(outputs.logits, dim=1)
pred = torch.argmax(probs, dim=1).item()
label = "Spam" if pred == 1 else "Ham"
confidence = float(probs[0][pred])
return label, confidence

st.title("📧 Spam vs Ham Classifier (BERT)")
msg = st.text_area("Enter your message:")
if st.button("Predict"):
if msg.strip() == "":
st.warning("Please enter a message.")
else:
label, conf = predict_spam(msg)
st.success(f"Prediction: {label} (Confidence: {conf:.2f})")
